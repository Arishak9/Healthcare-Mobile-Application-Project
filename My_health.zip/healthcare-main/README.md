# healthcare
This is a basic health care app which is developed by using XML and JAVA on Android Studio. For database SQlite is used.

